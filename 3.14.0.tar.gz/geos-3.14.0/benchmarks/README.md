## Benchmarks

A variety of programs to execute various kinds of tests, 
including benchmarks, stability and robustness tests.

### Building

Building the benchmark tests must be enabled using 

    cmake -DBUILD_BENCHMARKS=ON ..
